import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
import gsap from 'gsap';
import { crearEstelasOrbitales } from './modules/estelas.js';
import { crearPlataformaPublia } from './modules/plataforma.js';
import { createPubliaParticles } from './modules/particulas.js';
import { createPubliaSpaceBackground } from './modules/fondo.js';
import './style.css';

const canvas = document.querySelector('#scene');
const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: false, powerPreference: 'high-performance' });
renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.7));
renderer.setSize(innerWidth, innerHeight);
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.25;
const scene = new THREE.Scene();
scene.background = new THREE.Color('#050b1b');
const camera = new THREE.PerspectiveCamera(40, innerWidth / innerHeight, .1, 100);
const cameraBase = new THREE.Vector3(0, 2.4, 11.6);
camera.position.copy(cameraBase);
const target = new THREE.Vector3(0, 1.05, 0);
camera.lookAt(target);
const light = new THREE.HemisphereLight(0xcdefff, 0x1b2148, 3.3); scene.add(light);
const key = new THREE.DirectionalLight(0xbcefff, 5); key.position.set(-3, 6, 6); scene.add(key);
const rim = new THREE.PointLight(0x7c66ff, 110, 13); rim.position.set(3, 3, -2); scene.add(rim);
const amber = new THREE.PointLight(0xffba43, 45, 9); amber.position.set(-2, 3, 4); scene.add(amber);
const composer = new EffectComposer(renderer);
composer.addPass(new RenderPass(scene, camera));
const bloom = new UnrealBloomPass(new THREE.Vector2(innerWidth, innerHeight), .67, .65, .85);
composer.addPass(bloom);

const rig = new THREE.Group(); scene.add(rig);
const platform = crearPlataformaPublia({radius:2.15}); rig.add(platform.group);
const trails = crearEstelasOrbitales({quality: innerWidth < 700 ? 'low' : 'high'});
trails.grupo.position.y = 2.1; rig.add(trails.grupo);
const particles = createPubliaParticles({count:innerWidth < 700 ? 180 : 460, reducedMotion:matchMedia('(prefers-reduced-motion:reduce)').matches});
particles.root.position.y=2.0; rig.add(particles.root);
const bg = await createPubliaSpaceBackground(scene,{textureUrl:'/textures/atmosfera.webp'});
const loader = new GLTFLoader();
const [robotAsset, prismAsset] = await Promise.all([
 loader.loadAsync('/models/PUBLIA_P_robotica_v2.glb'),
 loader.loadAsync('/models/PUBLIA_prisma_suave_v2.glb')
]);
function normalizeModel(model, height){
 const box = new THREE.Box3().setFromObject(model);
 const size = box.getSize(new THREE.Vector3());
 const center = box.getCenter(new THREE.Vector3());
 model.position.sub(center);
 const wrap = new THREE.Group();
 wrap.add(model);
 wrap.scale.setScalar(height / Math.max(size.y,.001));
 return wrap;
}
const mascot = normalizeModel(robotAsset.scene, 3.15);
mascot.position.set(0, 2.18, 0);
rig.add(mascot);
mascot.traverse(o=>{if(o.isMesh){o.castShadow=false;o.material.side=THREE.DoubleSide;}});
const prism = normalizeModel(prismAsset.scene, 3.75);
prism.position.set(.3,2.25,-.45);
rig.add(prism);
prism.traverse(o=>{if(o.isMesh){o.material=o.material.clone();o.material.transparent=true;o.material.opacity=.36;o.material.depthWrite=false;o.material.side=THREE.DoubleSide;}});
const shardMeshes=[];
prism.traverse(o=>{if(o.isMesh && o.name.startsWith('Facet_')) shardMeshes.push(o);});
const original = shardMeshes.map(o=>({pos:o.position.clone(),rot:o.rotation.clone()}));
const iconNames=['INTELIGENCIA ARTIFICIAL','DESARROLLO WEB','AGENTES IA','COOPERATIVISMO','MULTIMEDIA','MARKETING','ECOLOGÍA','INFRAESTRUCTURA'];
const iconGroups=[];
const texLoader = new THREE.TextureLoader();
for(let i=0;i<8;i++){
 const texture=await texLoader.loadAsync(`/icons/icono_${String(i+1).padStart(2,'0')}.png`);
 texture.colorSpace=THREE.SRGBColorSpace;
 const group=new THREE.Group();
 const plate = new THREE.Mesh(new THREE.PlaneGeometry(.84,.96),new THREE.MeshBasicMaterial({color:0x0b2e54,transparent:true,opacity:.48,side:THREE.DoubleSide,depthWrite:false}));
 const border = new THREE.LineSegments(new THREE.EdgesGeometry(new THREE.PlaneGeometry(.84,.96)),new THREE.LineBasicMaterial({color:i%3===0?0xffc365:0x64cfff,transparent:true,opacity:.7}));
 border.position.z=.008;
 const icon = new THREE.Mesh(new THREE.PlaneGeometry(.65,.65),new THREE.MeshBasicMaterial({map:texture,transparent:true,depthWrite:false,side:THREE.DoubleSide}));
 icon.position.z=.02;
 group.add(plate,border,icon);
 // Tarjetas visibles alrededor de la P, por delante del prisma y de sus reflejos.
 const col=i<4?0:1;
 const row=i%4;
 group.position.set(col===0?-1.75:1.85,1.12+row*1.02,2.4);
 group.scale.setScalar(.83);
 group.userData={base:group.position.clone(),phase:i*.8};
 rig.add(group);iconGroups.push(group);
}
const pointer = new THREE.Vector2();
let paused=false, explosion=0, scrolling=0, elapsed=0;
const reduced = matchMedia('(prefers-reduced-motion: reduce)').matches;
const state={explode:0};
const isMobile=()=>innerWidth<700;
function placeRig(){
 rig.position.x = isMobile() ? 0.8 : innerWidth < 1100 ? 1.8 : 2.35;
 rig.position.y = isMobile() ? -1.65 : -.25;
 rig.scale.setScalar(isMobile() ? .72 : innerWidth < 1100 ? .83 : 1);
}
placeRig();
const clock = new THREE.Clock();
function frame(){
 const dt=Math.min(clock.getDelta(),.05);
 if(!paused&&!reduced)elapsed+=dt;
 const t=elapsed;
 const phase=state.explode;
 mascot.rotation.y=.13*Math.sin(t*.5)+phase*.65;
 mascot.rotation.x=.045*Math.sin(t*.7);
 mascot.position.y=2.18+Math.sin(t*1.1)*.095;
 prism.rotation.y=t*.085;
 prism.rotation.x=Math.sin(t*.27)*.1;
 prism.scale.setScalar(1+phase*.13);
 prism.traverse(o=>{if(o.isMesh)o.material.opacity=o.name==='Prism_Core'?.22+phase*.08:.38+phase*.2;});
 shardMeshes.forEach((o,i)=>{
  const orig=original[i];
  const a=i*2*Math.PI/shardMeshes.length;
  o.position.copy(orig.pos).add(new THREE.Vector3(Math.cos(a)*phase*.9,Math.sin(a*2)*phase*.55,Math.sin(a)*phase*.8));
  o.rotation.set(orig.rot.x+phase*.4,orig.rot.y+phase*.6,orig.rot.z);
 });
 trails.actualizar(t);
 trails.configurar({expandir:phase*.8,intensidad:1.15});
 platform.state.expansion=phase*.8;platform.update(t);
 particles.state.explode=phase;
 particles.state.orbit=.4;
 particles.update(t,dt);
 iconGroups.forEach((o,i)=>{
  const p=o.userData.base;
  o.position.set(p.x+Math.sin(t*.3+i)*.1,p.y+Math.sin(t*.8+i)*.12+phase*Math.sin(i*2)*.9,p.z+phase*.5);
  o.rotation.y=Math.sin(t*.42+i)*.17;
  o.lookAt(camera.position);
 });
 bg.update({time:t,pointerX:pointer.x,pointerY:pointer.y,scroll:scrolling});
 camera.position.x=THREE.MathUtils.lerp(camera.position.x,cameraBase.x+pointer.x*.3,dt*2);
 camera.position.y=THREE.MathUtils.lerp(camera.position.y,cameraBase.y+pointer.y*.15,dt*2);
 camera.lookAt(target);
 composer.render();
}
renderer.setAnimationLoop(frame);
window.addEventListener('pointermove',e=>{pointer.set((e.clientX/innerWidth-.5)*2,(.5-e.clientY/innerHeight)*2);});
window.addEventListener('scroll',()=>{scrolling=Math.min(scrollY/Math.max(innerHeight,1),1);},{passive:true});
window.addEventListener('resize',()=>{
 renderer.setSize(innerWidth,innerHeight);
 composer.setSize(innerWidth,innerHeight);
 camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();
 placeRig();
});
const animateBurst=()=>gsap.to(state,{explode:state.explode>.5?0:1,duration:1.6,ease:'power2.inOut'});
document.querySelector('#explode').addEventListener('click',animateBurst);
document.querySelector('#reset').addEventListener('click',()=>gsap.to(state,{explode:0,duration:1.1}));
document.querySelector('#pause').addEventListener('click',e=>{paused=!paused;e.currentTarget.textContent=paused?'▶ Reanudar':'Ⅱ Pausar';e.currentTarget.setAttribute('aria-pressed',String(paused));});
document.querySelector('#enterprise').addEventListener('click',()=>{animateBurst();document.querySelector('.next h2').textContent='Infraestructura soberana para empresas.';document.querySelector('#soluciones').scrollIntoView({behavior:reduced?'auto':'smooth'});});
document.querySelector('#efficiency').addEventListener('click',()=>{animateBurst();document.querySelector('.next h2').textContent='Haz más con menos, sin perder el control.';document.querySelector('#soluciones').scrollIntoView({behavior:reduced?'auto':'smooth'});});

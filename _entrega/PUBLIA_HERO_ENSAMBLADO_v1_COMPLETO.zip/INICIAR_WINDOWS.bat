@echo off
cd /d "%~dp0"
where node >nul 2>&1 || (echo Instala Node.js 20 o superior y vuelve a ejecutar. & pause & exit /b 1)
if not exist node_modules (
 echo Instalando dependencias Three.js, GSAP y Vite...
 call npm install
 if errorlevel 1 (echo Fallo la instalacion. Comprueba tu conexion a internet. & pause & exit /b 1)
)
echo Abre http://localhost:5173 en tu navegador
start "" http://localhost:5173
call npm run dev
pause

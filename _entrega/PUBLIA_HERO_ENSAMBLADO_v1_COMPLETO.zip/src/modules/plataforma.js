import * as THREE from 'three';

/** Plataforma holográfica Publia. Geometría real; sin imágenes ni dependencias extra. */
export function crearPlataformaPublia({ radius = 2.1 } = {}) {
  const group = new THREE.Group();
  group.name = 'PUBLIA_Plataforma_Luminosa';
  const dark = new THREE.MeshStandardMaterial({ color: 0x091b35, metalness: .76, roughness: .24 });
  const rim = new THREE.MeshStandardMaterial({ color: 0x12385a, metalness: .86, roughness: .19 });
  const cyan = new THREE.MeshBasicMaterial({ color: 0x4deaff, transparent: true, opacity: .85, depthWrite: false });
  const blue = new THREE.MeshBasicMaterial({ color: 0x238cff, transparent: true, opacity: .8, depthWrite: false });
  const amber = new THREE.MeshBasicMaterial({ color: 0xffb53b, transparent: true, opacity: .9, depthWrite: false });
  const glow = new THREE.MeshBasicMaterial({ color: 0x28baff, transparent: true, opacity: .09, depthWrite: false, side: THREE.DoubleSide });
  const add = (geo, material, y=0, name='') => {
    const mesh = new THREE.Mesh(geo, material); mesh.position.y=y; mesh.name=name; group.add(mesh); return mesh;
  };
  add(new THREE.CylinderGeometry(radius, radius*1.03, .18, 96), dark, -.1, 'base');
  add(new THREE.CylinderGeometry(radius*.94, radius*.98, .045, 96), rim, .014, 'tapa');
  const rings=[];
  const ring=(r,t,material,y,name)=>{
    const m=add(new THREE.TorusGeometry(r,t,8,128),material,y,name);m.rotation.x=Math.PI/2;rings.push(m);return m;
  };
  ring(radius*.96,.026,cyan,.047,'aro_exterior');
  ring(radius*.78,.013,blue,.05,'aro_intermedio');
  ring(radius*.47,.018,amber,.053,'aro_central');
  const segmented=new THREE.Group();segmented.name='segmentos_rotatorios';group.add(segmented);
  for(let i=0;i<32;i++){
    const a=i*Math.PI*2/32;
    const segment=new THREE.Mesh(new THREE.BoxGeometry(.14,.012,.025),i%4===0?amber:cyan);
    segment.position.set(Math.cos(a)*radius*.86,.063,Math.sin(a)*radius*.86);
    segment.rotation.y=-a;segmented.add(segment);
  }
  const beam=add(new THREE.CylinderGeometry(radius*.52,radius*.72,1.8,96,1,true),glow,.92,'columna_luminosa');
  const pulseMat=new THREE.MeshBasicMaterial({color:0x5ddfff,transparent:true,opacity:.2,depthWrite:false,side:THREE.DoubleSide});
  const pulse=add(new THREE.CircleGeometry(radius*.76,96),pulseMat,.067,'pulso');pulse.rotation.x=-Math.PI/2;
  const light=new THREE.PointLight(0x35baff,8,6);light.position.set(0,.75,0);group.add(light);
  const state={ intensity:1, expansion:0, paused:false };
  function update(time){
    if(state.paused)return;
    segmented.rotation.y=time*.13;
    const breath=.5+.5*Math.sin(time*1.6);
    pulse.scale.setScalar(.94+breath*.09+state.expansion*.22);
    pulseMat.opacity=(.07+.12*breath)*state.intensity;
    beam.material.opacity=(.045+.055*breath)*state.intensity;
    light.intensity=(3.8+2.4*breath)*state.intensity;
    rings.forEach((r,i)=>r.scale.setScalar(1+state.expansion*(.08+i*.035));
  }
  function dispose(){group.traverse(o=>{if(o.isMesh)o.geometry.dispose()});[dark,rim,cyan,blue,amber,glow,pulseMat].forEach(m=>m.dispose());}
  return {group,state,update,dispose};
}
// Integración: const p=crearPlataformaPublia(); scene.add(p.group);
// En render loop: p.update(clock.getElapsedTime());
// Para ScrollTrigger: p.state.expansion = self.progress;

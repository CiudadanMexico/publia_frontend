// PUBLIA R03-F: fondo espacial independiente para Three.js + Astro.
// npm install three
import * as THREE from 'three';
export async function createPubliaSpaceBackground(scene,{textureUrl='/publia/atmosfera.webp',farCount=110,nearCount=35}={}){
 const group=new THREE.Group();group.name='PubliaSpaceBackground';scene.add(group);
 const loader=new THREE.TextureLoader();const texture=await loader.loadAsync(textureUrl);texture.colorSpace=THREE.SRGBColorSpace;
 const nebula=new THREE.Mesh(new THREE.PlaneGeometry(28,16),new THREE.MeshBasicMaterial({map:texture,transparent:true,opacity:.92,depthWrite:false,side:THREE.DoubleSide}));nebula.name='NebulaLayer';nebula.position.set(0,0,-16);nebula.renderOrder=-20;group.add(nebula);
 const layers=[];
 for(const [count,depth,size,opacity] of [[farCount,-11,.025,.42],[nearCount,-7,.052,.68]]){
  const pts=new Float32Array(count*3);let seed=count*11+7;const rnd=()=>{seed=(1664525*seed+1013904223)>>>0;return seed/4294967296};
  for(let i=0;i<count;i++){pts[i*3]=(rnd()-.5)*25;pts[i*3+1]=(rnd()-.5)*13;pts[i*3+2]=depth+(rnd()-.5)*.8}
  const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.BufferAttribute(pts,3));
  const material=new THREE.PointsMaterial({color:0xb5dfff,size,transparent:true,opacity,depthWrite:false,sizeAttenuation:true});
  const points=new THREE.Points(geo,material);points.name=depth===-11?'FarStars':'NearStars';group.add(points);layers.push(points);
 }
 let progress=0;let reduced=typeof window!=='undefined'&&window.matchMedia('(prefers-reduced-motion: reduce)').matches;
 function update({time=0,pointerX=0,pointerY=0,scroll=progress}={}){
  progress=THREE.MathUtils.clamp(scroll,0,1);const mx=reduced?0:pointerX,my=reduced?0:pointerY;
  nebula.position.x=-mx*.11;nebula.position.y=-my*.07-progress*.14;
  layers[0].position.set(mx*.14,my*.09,-0);layers[1].position.set(mx*.39,my*.22,0);
  if(!reduced){layers[0].rotation.z=Math.sin(time*.04)*.003;layers[1].rotation.z=Math.sin(time*.08)*.006}
 }
 return {group,update,setReducedMotion(v){reduced=Boolean(v)},dispose(){group.traverse(o=>{o.geometry?.dispose();if(o.material){if(Array.isArray(o.material))o.material.forEach(m=>m.dispose());else o.material.dispose()}});texture.dispose();scene.remove(group)}};
}
// Ejemplo: const bg=await createPubliaSpaceBackground(scene);
// En cada frame: bg.update({time:clock.getElapsedTime(),pointerX, pointerY, scroll:progress});
// El fondo se sitúa detrás de los objetos, no genera partículas reactivas.
